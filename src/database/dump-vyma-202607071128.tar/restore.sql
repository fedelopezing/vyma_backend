--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 18.3
-- Dumped by pg_dump version 18.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE vyma;
--
-- Name: vyma; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE vyma WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


ALTER DATABASE vyma OWNER TO postgres;

\unrestrict (null)
\connect vyma
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: unaccent; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS unaccent WITH SCHEMA public;


--
-- Name: EXTENSION unaccent; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION unaccent IS 'text search dictionary that removes accents';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: events_estado_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.events_estado_enum AS ENUM (
    'BORRADOR',
    'PUBLICADO'
);


ALTER TYPE public.events_estado_enum OWNER TO postgres;

--
-- Name: events_organizador_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.events_organizador_enum AS ENUM (
    'CCPS',
    'SOCIO'
);


ALTER TYPE public.events_organizador_enum OWNER TO postgres;

--
-- Name: members_fee_type_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.members_fee_type_enum AS ENUM (
    'ANNUAL',
    'SEMIANNUAL'
);


ALTER TYPE public.members_fee_type_enum OWNER TO postgres;

--
-- Name: members_status_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.members_status_enum AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED',
    'INACTIVE'
);


ALTER TYPE public.members_status_enum OWNER TO postgres;

--
-- Name: news_categoria_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.news_categoria_enum AS ENUM (
    'NOTICIA',
    'COMUNICADO',
    'EVENTO_SOCIO'
);


ALTER TYPE public.news_categoria_enum OWNER TO postgres;

--
-- Name: news_estado_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.news_estado_enum AS ENUM (
    'BORRADOR',
    'PUBLICADO'
);


ALTER TYPE public.news_estado_enum OWNER TO postgres;

--
-- Name: profiles_documenttype_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.profiles_documenttype_enum AS ENUM (
    'RUC',
    'CI',
    'PASSPORT',
    'OTHER'
);


ALTER TYPE public.profiles_documenttype_enum OWNER TO postgres;

--
-- Name: profiles_gender_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.profiles_gender_enum AS ENUM (
    'none',
    'male',
    'female'
);


ALTER TYPE public.profiles_gender_enum OWNER TO postgres;

--
-- Name: schedules_dayofweek_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.schedules_dayofweek_enum AS ENUM (
    'monday',
    'tuesday',
    'wednesday',
    'thursday',
    'friday',
    'saturday',
    'sunday'
);


ALTER TYPE public.schedules_dayofweek_enum OWNER TO postgres;

--
-- Name: users_provider_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.users_provider_enum AS ENUM (
    'local',
    'google',
    'facebook',
    'twitter',
    'github',
    'linkedin'
);


ALTER TYPE public.users_provider_enum OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activation_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.activation_tokens (
    id bigint NOT NULL,
    "tokenHash" text NOT NULL,
    "expiresAt" timestamp without time zone NOT NULL,
    "isUsed" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    user_id bigint
);


ALTER TABLE public.activation_tokens OWNER TO postgres;

--
-- Name: COLUMN activation_tokens."tokenHash"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.activation_tokens."tokenHash" IS 'Token de activación hasheado con bcrypt';


--
-- Name: activation_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.activation_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.activation_tokens_id_seq OWNER TO postgres;

--
-- Name: activation_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.activation_tokens_id_seq OWNED BY public.activation_tokens.id;


--
-- Name: ads; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ads (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    image_url_es character varying(500) NOT NULL,
    image_url_en character varying(500),
    link_url_es character varying(500),
    link_url_en character varying(500),
    alt_es character varying(255),
    alt_en character varying(255),
    is_active boolean DEFAULT true NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    company_id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.ads OWNER TO postgres;

--
-- Name: COLUMN ads.image_url_es; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ads.image_url_es IS 'Cloudinary URL for Spanish banner';


--
-- Name: COLUMN ads.image_url_en; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ads.image_url_en IS 'Cloudinary URL for English banner';


--
-- Name: companies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.companies (
    id bigint NOT NULL,
    uuid uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    "taxId" character varying(50),
    email character varying(100),
    phone character varying(20),
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "activeModules" text DEFAULT ''::text NOT NULL,
    domain character varying(255)
);


ALTER TABLE public.companies OWNER TO postgres;

--
-- Name: companies_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.companies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.companies_id_seq OWNER TO postgres;

--
-- Name: companies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.companies_id_seq OWNED BY public.companies.id;


--
-- Name: events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.events (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "slugEs" character varying(255) NOT NULL,
    "slugEn" character varying(255),
    "tituloEs" character varying(255) NOT NULL,
    "tituloEn" character varying(255),
    "resumenEs" text NOT NULL,
    "resumenEn" text,
    "contenidoEs" text NOT NULL,
    "contenidoEn" text,
    "imagenPortada" character varying(500) NOT NULL,
    "fechaEvento" timestamp with time zone NOT NULL,
    "ubicacionEs" character varying(500),
    "ubicacionEn" character varying(500),
    "linkRegistro" character varying(500),
    organizador public.events_organizador_enum NOT NULL,
    "organizadorNombre" character varying(255),
    estado public.events_estado_enum DEFAULT 'BORRADOR'::public.events_estado_enum NOT NULL,
    autor_id bigint NOT NULL,
    company_id bigint NOT NULL,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public.events OWNER TO postgres;

--
-- Name: COLUMN events."contenidoEs"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.events."contenidoEs" IS 'HTML enriquecido sanitizado ES';


--
-- Name: COLUMN events."contenidoEn"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.events."contenidoEn" IS 'HTML enriquecido sanitizado EN';


--
-- Name: COLUMN events."imagenPortada"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.events."imagenPortada" IS 'Cloudinary URL';


--
-- Name: exchange_rates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.exchange_rates (
    id bigint NOT NULL,
    currency character varying(10) NOT NULL,
    "purchasePrice" integer NOT NULL,
    "salePrice" integer NOT NULL,
    "isFallback" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    company_id bigint NOT NULL
);


ALTER TABLE public.exchange_rates OWNER TO postgres;

--
-- Name: exchange_rates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.exchange_rates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.exchange_rates_id_seq OWNER TO postgres;

--
-- Name: exchange_rates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.exchange_rates_id_seq OWNED BY public.exchange_rates.id;


--
-- Name: members; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.members (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    company_id bigint NOT NULL,
    email character varying(255) NOT NULL,
    fee_type public.members_fee_type_enum NOT NULL,
    company_name character varying(255) NOT NULL,
    tax_id character varying(50) NOT NULL,
    address character varying(255) NOT NULL,
    city character varying(100) NOT NULL,
    country character varying(100) NOT NULL,
    phone character varying(50) NOT NULL,
    category character varying(100) NOT NULL,
    representative_name character varying(255) NOT NULL,
    representative_email character varying(255) NOT NULL,
    representative_phone character varying(50) NOT NULL,
    social_links jsonb,
    marketing_contact jsonb,
    logo_url text,
    is_featured boolean DEFAULT false NOT NULL,
    status public.members_status_enum DEFAULT 'PENDING'::public.members_status_enum NOT NULL,
    version integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.members OWNER TO postgres;

--
-- Name: migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    "timestamp" bigint NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.migrations OWNER TO postgres;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.migrations_id_seq OWNER TO postgres;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: news; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.news (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "slugEs" character varying(255) NOT NULL,
    "slugEn" character varying(255),
    "tituloEs" character varying(255) NOT NULL,
    "tituloEn" character varying(255),
    "resumenEs" text NOT NULL,
    "resumenEn" text,
    "contenidoEs" text NOT NULL,
    "contenidoEn" text,
    "imagenPortada" character varying(500) NOT NULL,
    categoria public.news_categoria_enum DEFAULT 'NOTICIA'::public.news_categoria_enum NOT NULL,
    estado public.news_estado_enum DEFAULT 'BORRADOR'::public.news_estado_enum NOT NULL,
    autor_id bigint NOT NULL,
    company_id bigint NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "deletedAt" timestamp without time zone
);


ALTER TABLE public.news OWNER TO postgres;

--
-- Name: COLUMN news."contenidoEs"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.news."contenidoEs" IS 'Almacena HTML enriquecido sanitizado';


--
-- Name: COLUMN news."contenidoEn"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.news."contenidoEn" IS 'Almacena HTML enriquecido sanitizado bilingüe';


--
-- Name: COLUMN news."imagenPortada"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.news."imagenPortada" IS 'Cloudinary URL';


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.permissions (
    id integer NOT NULL,
    action character varying NOT NULL
);


ALTER TABLE public.permissions OWNER TO postgres;

--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.permissions_id_seq OWNER TO postgres;

--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- Name: professions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.professions (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "deletedAt" timestamp without time zone,
    company_id bigint NOT NULL
);


ALTER TABLE public.professions OWNER TO postgres;

--
-- Name: professions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.professions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.professions_id_seq OWNER TO postgres;

--
-- Name: professions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.professions_id_seq OWNED BY public.professions.id;


--
-- Name: profiles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.profiles (
    id bigint NOT NULL,
    document character varying(50),
    "documentType" public.profiles_documenttype_enum DEFAULT 'CI'::public.profiles_documenttype_enum NOT NULL,
    bio text,
    phone character varying(20),
    address character varying(200),
    city character varying(50),
    gender public.profiles_gender_enum DEFAULT 'none'::public.profiles_gender_enum NOT NULL,
    birth_date timestamp without time zone,
    "avatarUrl" text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    profession_id bigint,
    user_id bigint NOT NULL
);


ALTER TABLE public.profiles OWNER TO postgres;

--
-- Name: profiles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.profiles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.profiles_id_seq OWNER TO postgres;

--
-- Name: profiles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.profiles_id_seq OWNED BY public.profiles.id;


--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.refresh_tokens (
    id bigint NOT NULL,
    uuid uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "tokenHash" text NOT NULL,
    "expiresAt" timestamp without time zone NOT NULL,
    "isRevoked" boolean DEFAULT false NOT NULL,
    "ipAddress" character varying(255),
    "userAgent" text,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    user_id bigint
);


ALTER TABLE public.refresh_tokens OWNER TO postgres;

--
-- Name: COLUMN refresh_tokens."tokenHash"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.refresh_tokens."tokenHash" IS 'Token hasheado con bcrypt';


--
-- Name: COLUMN refresh_tokens."ipAddress"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.refresh_tokens."ipAddress" IS 'IP de origen del login';


--
-- Name: COLUMN refresh_tokens."userAgent"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.refresh_tokens."userAgent" IS 'User-Agent del cliente';


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.refresh_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.refresh_tokens_id_seq OWNER TO postgres;

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.refresh_tokens_id_seq OWNED BY public.refresh_tokens.id;


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role_permissions (
    "rolesId" integer NOT NULL,
    "permissionsId" integer NOT NULL
);


ALTER TABLE public.role_permissions OWNER TO postgres;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roles_id_seq OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: schedule_breaks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schedule_breaks (
    id integer NOT NULL,
    "breakStart" time without time zone NOT NULL,
    "breakEnd" time without time zone NOT NULL,
    "scheduleId" integer,
    company_id bigint NOT NULL
);


ALTER TABLE public.schedule_breaks OWNER TO postgres;

--
-- Name: schedule_breaks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.schedule_breaks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.schedule_breaks_id_seq OWNER TO postgres;

--
-- Name: schedule_breaks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.schedule_breaks_id_seq OWNED BY public.schedule_breaks.id;


--
-- Name: schedules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schedules (
    id integer NOT NULL,
    "dayOfWeek" public.schedules_dayofweek_enum NOT NULL,
    "startTime" time without time zone NOT NULL,
    "endTime" time without time zone NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "profileId" bigint,
    company_id bigint NOT NULL
);


ALTER TABLE public.schedules OWNER TO postgres;

--
-- Name: schedules_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.schedules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.schedules_id_seq OWNER TO postgres;

--
-- Name: schedules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.schedules_id_seq OWNED BY public.schedules.id;


--
-- Name: services; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.services (
    id bigint NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    duration_minutes integer NOT NULL,
    price numeric(10,2) NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    "deletedAt" timestamp without time zone,
    company_id bigint NOT NULL
);


ALTER TABLE public.services OWNER TO postgres;

--
-- Name: services_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.services_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.services_id_seq OWNER TO postgres;

--
-- Name: services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.services_id_seq OWNED BY public.services.id;


--
-- Name: user_companies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_companies (
    "userId" bigint NOT NULL,
    "companyId" bigint NOT NULL,
    "roleId" integer NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_companies OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    uuid uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(100) NOT NULL,
    "passwordHash" character varying(255) NOT NULL,
    provider public.users_provider_enum DEFAULT 'local'::public.users_provider_enum NOT NULL,
    "providerId" character varying(255),
    "accessToken" text,
    "refreshToken" text,
    "tokenExpiry" timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    "isSuperAdmin" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    role_id integer
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: COLUMN users.provider; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.provider IS 'Proveedor de autenticación';


--
-- Name: COLUMN users."providerId"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users."providerId" IS 'ID único del usuario en el proveedor de redes sociales';


--
-- Name: COLUMN users."accessToken"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users."accessToken" IS 'Token de acceso del proveedor (si necesitas interactuar con su API)';


--
-- Name: COLUMN users."refreshToken"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users."refreshToken" IS 'Token de actualización (si aplica para la API del proveedor)';


--
-- Name: COLUMN users."tokenExpiry"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users."tokenExpiry" IS 'Fecha de expiración del token de acceso (opcional)';


--
-- Name: COLUMN users."isSuperAdmin"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users."isSuperAdmin" IS 'Indicates if the user has super admin privileges across all tenants';


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: activation_tokens id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activation_tokens ALTER COLUMN id SET DEFAULT nextval('public.activation_tokens_id_seq'::regclass);


--
-- Name: companies id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.companies ALTER COLUMN id SET DEFAULT nextval('public.companies_id_seq'::regclass);


--
-- Name: exchange_rates id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exchange_rates ALTER COLUMN id SET DEFAULT nextval('public.exchange_rates_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: professions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.professions ALTER COLUMN id SET DEFAULT nextval('public.professions_id_seq'::regclass);


--
-- Name: profiles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.profiles ALTER COLUMN id SET DEFAULT nextval('public.profiles_id_seq'::regclass);


--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('public.refresh_tokens_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: schedule_breaks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_breaks ALTER COLUMN id SET DEFAULT nextval('public.schedule_breaks_id_seq'::regclass);


--
-- Name: schedules id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedules ALTER COLUMN id SET DEFAULT nextval('public.schedules_id_seq'::regclass);


--
-- Name: services id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services ALTER COLUMN id SET DEFAULT nextval('public.services_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: activation_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.activation_tokens (id, "tokenHash", "expiresAt", "isUsed", "createdAt", user_id) FROM stdin;
\.
COPY public.activation_tokens (id, "tokenHash", "expiresAt", "isUsed", "createdAt", user_id) FROM '$$PATH$$/5238.dat';

--
-- Data for Name: ads; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ads (id, image_url_es, image_url_en, link_url_es, link_url_en, alt_es, alt_en, is_active, "order", company_id, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.ads (id, image_url_es, image_url_en, link_url_es, link_url_en, alt_es, alt_en, is_active, "order", company_id, created_at, updated_at, deleted_at) FROM '$$PATH$$/5249.dat';

--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.companies (id, uuid, name, "taxId", email, phone, "isActive", "createdAt", "updatedAt", "activeModules", domain) FROM stdin;
\.
COPY public.companies (id, uuid, name, "taxId", email, phone, "isActive", "createdAt", "updatedAt", "activeModules", domain) FROM '$$PATH$$/5223.dat';

--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.events (id, "slugEs", "slugEn", "tituloEs", "tituloEn", "resumenEs", "resumenEn", "contenidoEs", "contenidoEn", "imagenPortada", "fechaEvento", "ubicacionEs", "ubicacionEn", "linkRegistro", organizador, "organizadorNombre", estado, autor_id, company_id, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public.events (id, "slugEs", "slugEn", "tituloEs", "tituloEn", "resumenEs", "resumenEn", "contenidoEs", "contenidoEn", "imagenPortada", "fechaEvento", "ubicacionEs", "ubicacionEn", "linkRegistro", organizador, "organizadorNombre", estado, autor_id, company_id, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/5248.dat';

--
-- Data for Name: exchange_rates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.exchange_rates (id, currency, "purchasePrice", "salePrice", "isFallback", "createdAt", "updatedAt", company_id) FROM stdin;
\.
COPY public.exchange_rates (id, currency, "purchasePrice", "salePrice", "isFallback", "createdAt", "updatedAt", company_id) FROM '$$PATH$$/5225.dat';

--
-- Data for Name: members; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.members (id, company_id, email, fee_type, company_name, tax_id, address, city, country, phone, category, representative_name, representative_email, representative_phone, social_links, marketing_contact, logo_url, is_featured, status, version, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.members (id, company_id, email, fee_type, company_name, tax_id, address, city, country, phone, category, representative_name, representative_email, representative_phone, social_links, marketing_contact, logo_url, is_featured, status, version, created_at, updated_at, deleted_at) FROM '$$PATH$$/5242.dat';

--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.migrations (id, "timestamp", name) FROM stdin;
\.
COPY public.migrations (id, "timestamp", name) FROM '$$PATH$$/5219.dat';

--
-- Data for Name: news; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.news (id, "slugEs", "slugEn", "tituloEs", "tituloEn", "resumenEs", "resumenEn", "contenidoEs", "contenidoEn", "imagenPortada", categoria, estado, autor_id, company_id, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public.news (id, "slugEs", "slugEn", "tituloEs", "tituloEn", "resumenEs", "resumenEn", "contenidoEs", "contenidoEn", "imagenPortada", categoria, estado, autor_id, company_id, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/5241.dat';

--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.permissions (id, action) FROM stdin;
\.
COPY public.permissions (id, action) FROM '$$PATH$$/5221.dat';

--
-- Data for Name: professions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.professions (id, name, "isActive", "deletedAt", company_id) FROM stdin;
\.
COPY public.professions (id, name, "isActive", "deletedAt", company_id) FROM '$$PATH$$/5231.dat';

--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.profiles (id, document, "documentType", bio, phone, address, city, gender, birth_date, "avatarUrl", created_at, updated_at, profession_id, user_id) FROM stdin;
\.
COPY public.profiles (id, document, "documentType", bio, phone, address, city, gender, birth_date, "avatarUrl", created_at, updated_at, profession_id, user_id) FROM '$$PATH$$/5236.dat';

--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.refresh_tokens (id, uuid, "tokenHash", "expiresAt", "isRevoked", "ipAddress", "userAgent", "createdAt", user_id) FROM stdin;
\.
COPY public.refresh_tokens (id, uuid, "tokenHash", "expiresAt", "isRevoked", "ipAddress", "userAgent", "createdAt", user_id) FROM '$$PATH$$/5240.dat';

--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.role_permissions ("rolesId", "permissionsId") FROM stdin;
\.
COPY public.role_permissions ("rolesId", "permissionsId") FROM '$$PATH$$/5247.dat';

--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (id, name) FROM stdin;
\.
COPY public.roles (id, name) FROM '$$PATH$$/5227.dat';

--
-- Data for Name: schedule_breaks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schedule_breaks (id, "breakStart", "breakEnd", "scheduleId", company_id) FROM stdin;
\.
COPY public.schedule_breaks (id, "breakStart", "breakEnd", "scheduleId", company_id) FROM '$$PATH$$/5246.dat';

--
-- Data for Name: schedules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schedules (id, "dayOfWeek", "startTime", "endTime", "isActive", "profileId", company_id) FROM stdin;
\.
COPY public.schedules (id, "dayOfWeek", "startTime", "endTime", "isActive", "profileId", company_id) FROM '$$PATH$$/5244.dat';

--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.services (id, name, description, duration_minutes, price, "isActive", created_at, updated_at, "deletedAt", company_id) FROM stdin;
\.
COPY public.services (id, name, description, duration_minutes, price, "isActive", created_at, updated_at, "deletedAt", company_id) FROM '$$PATH$$/5233.dat';

--
-- Data for Name: user_companies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_companies ("userId", "companyId", "roleId", "isActive", "createdAt") FROM stdin;
\.
COPY public.user_companies ("userId", "companyId", "roleId", "isActive", "createdAt") FROM '$$PATH$$/5234.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, uuid, name, email, "passwordHash", provider, "providerId", "accessToken", "refreshToken", "tokenExpiry", "isActive", "isSuperAdmin", "createdAt", "updatedAt", role_id) FROM stdin;
\.
COPY public.users (id, uuid, name, email, "passwordHash", provider, "providerId", "accessToken", "refreshToken", "tokenExpiry", "isActive", "isSuperAdmin", "createdAt", "updatedAt", role_id) FROM '$$PATH$$/5229.dat';

--
-- Name: activation_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.activation_tokens_id_seq', 1, false);


--
-- Name: companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.companies_id_seq', 3, true);


--
-- Name: exchange_rates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.exchange_rates_id_seq', 1, false);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.migrations_id_seq', 18, true);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.permissions_id_seq', 147, true);


--
-- Name: professions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.professions_id_seq', 1, false);


--
-- Name: profiles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.profiles_id_seq', 1, false);


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.refresh_tokens_id_seq', 6, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_id_seq', 30, true);


--
-- Name: schedule_breaks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.schedule_breaks_id_seq', 1, false);


--
-- Name: schedules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.schedules_id_seq', 1, false);


--
-- Name: services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.services_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 24, true);


--
-- Name: user_companies PK_0b5b4fd1b21f221e3f91a438d93; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_companies
    ADD CONSTRAINT "PK_0b5b4fd1b21f221e3f91a438d93" PRIMARY KEY ("userId", "companyId");


--
-- Name: members PK_28b53062261b996d9c99fa12404; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT "PK_28b53062261b996d9c99fa12404" PRIMARY KEY (id);


--
-- Name: exchange_rates PK_33a614bad9e61956079d817ebe2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exchange_rates
    ADD CONSTRAINT "PK_33a614bad9e61956079d817ebe2" PRIMARY KEY (id);


--
-- Name: news PK_39a43dfcb6007180f04aff2357e; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.news
    ADD CONSTRAINT "PK_39a43dfcb6007180f04aff2357e" PRIMARY KEY (id);


--
-- Name: events PK_40731c7151fe4be3116e45ddf73; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT "PK_40731c7151fe4be3116e45ddf73" PRIMARY KEY (id);


--
-- Name: role_permissions PK_7931614007a93423204b4b73240; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT "PK_7931614007a93423204b4b73240" PRIMARY KEY ("rolesId", "permissionsId");


--
-- Name: refresh_tokens PK_7d8bee0204106019488c4c50ffa; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT "PK_7d8bee0204106019488c4c50ffa" PRIMARY KEY (id);


--
-- Name: schedules PK_7e33fc2ea755a5765e3564e66dd; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedules
    ADD CONSTRAINT "PK_7e33fc2ea755a5765e3564e66dd" PRIMARY KEY (id);


--
-- Name: activation_tokens PK_841f31a72cda6b2c39c861dbf0c; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activation_tokens
    ADD CONSTRAINT "PK_841f31a72cda6b2c39c861dbf0c" PRIMARY KEY (id);


--
-- Name: migrations PK_8c82d7f526340ab734260ea46be; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT "PK_8c82d7f526340ab734260ea46be" PRIMARY KEY (id);


--
-- Name: profiles PK_8e520eb4da7dc01d0e190447c8e; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT "PK_8e520eb4da7dc01d0e190447c8e" PRIMARY KEY (id);


--
-- Name: permissions PK_920331560282b8bd21bb02290df; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT "PK_920331560282b8bd21bb02290df" PRIMARY KEY (id);


--
-- Name: professions PK_9247c0d4b30fc6b796d59262058; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.professions
    ADD CONSTRAINT "PK_9247c0d4b30fc6b796d59262058" PRIMARY KEY (id);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: ads PK_a7af7d1998037a97076f758fc23; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ads
    ADD CONSTRAINT "PK_a7af7d1998037a97076f758fc23" PRIMARY KEY (id);


--
-- Name: services PK_ba2d347a3168a296416c6c5ccb2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT "PK_ba2d347a3168a296416c6c5ccb2" PRIMARY KEY (id);


--
-- Name: roles PK_c1433d71a4838793a49dcad46ab; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT "PK_c1433d71a4838793a49dcad46ab" PRIMARY KEY (id);


--
-- Name: companies PK_d4bc3e82a314fa9e29f652c2c22; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT "PK_d4bc3e82a314fa9e29f652c2c22" PRIMARY KEY (id);


--
-- Name: schedule_breaks PK_d8b9da07c5926fb28d2b7c371e8; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_breaks
    ADD CONSTRAINT "PK_d8b9da07c5926fb28d2b7c371e8" PRIMARY KEY (id);


--
-- Name: activation_tokens REL_995711dd58f244ad95c829e3e3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activation_tokens
    ADD CONSTRAINT "REL_995711dd58f244ad95c829e3e3" UNIQUE (user_id);


--
-- Name: profiles REL_9e432b7df0d182f8d292902d1a; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT "REL_9e432b7df0d182f8d292902d1a" UNIQUE (user_id);


--
-- Name: services UQ_019d74f7abcdcb5a0113010cb03; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT "UQ_019d74f7abcdcb5a0113010cb03" UNIQUE (name);


--
-- Name: news UQ_1576f8d0c6b623100b738854305; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.news
    ADD CONSTRAINT "UQ_1576f8d0c6b623100b738854305" UNIQUE ("slugEn");


--
-- Name: permissions UQ_1c1e0637ecf1f6401beb9a68abe; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT "UQ_1c1e0637ecf1f6401beb9a68abe" UNIQUE (action);


--
-- Name: news UQ_253bdc6e0ca2764a2532f0da4a9; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.news
    ADD CONSTRAINT "UQ_253bdc6e0ca2764a2532f0da4a9" UNIQUE ("slugEs");


--
-- Name: members UQ_2714af51e3f7dd42cf66eeb08d6; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT "UQ_2714af51e3f7dd42cf66eeb08d6" UNIQUE (email);


--
-- Name: events UQ_47c7fa7eec758c3544d4d17ad8e; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT "UQ_47c7fa7eec758c3544d4d17ad8e" UNIQUE ("slugEn");


--
-- Name: roles UQ_648e3f5447f725579d7d4ffdfb7; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT "UQ_648e3f5447f725579d7d4ffdfb7" UNIQUE (name);


--
-- Name: companies UQ_89a223b4d883067d909eedd3558; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT "UQ_89a223b4d883067d909eedd3558" UNIQUE (domain);


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: professions UQ_b273de78f494fa9da6952ffa703; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.professions
    ADD CONSTRAINT "UQ_b273de78f494fa9da6952ffa703" UNIQUE (name);


--
-- Name: events UQ_bde873123073465e9a66da7f414; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT "UQ_bde873123073465e9a66da7f414" UNIQUE ("slugEs");


--
-- Name: companies UQ_companies_domain; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT "UQ_companies_domain" UNIQUE (domain);


--
-- Name: IDX_0b5b4fd1b21f221e3f91a438d9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_0b5b4fd1b21f221e3f91a438d9" ON public.user_companies USING btree ("userId", "companyId");


--
-- Name: IDX_0cb93c5877d37e954e2aa59e52; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_0cb93c5877d37e954e2aa59e52" ON public.role_permissions USING btree ("rolesId");


--
-- Name: IDX_295e2ec0606b47e50687ff46c3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_295e2ec0606b47e50687ff46c3" ON public.user_companies USING btree ("userId");


--
-- Name: IDX_2badd7fe7d9fce6aa939a3f9d9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_2badd7fe7d9fce6aa939a3f9d9" ON public.exchange_rates USING btree (currency);


--
-- Name: IDX_2ebddf816e97f763b7a0d36179; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_2ebddf816e97f763b7a0d36179" ON public.members USING btree (company_name);


--
-- Name: IDX_4312587691718bbddaf92b4c86; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_4312587691718bbddaf92b4c86" ON public.schedules USING btree (company_id);


--
-- Name: IDX_4713fa1afaa73ebeeef2d3a8ad; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_4713fa1afaa73ebeeef2d3a8ad" ON public.professions USING btree (company_id);


--
-- Name: IDX_4d5b799d50bc13ce547dbac3bb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_4d5b799d50bc13ce547dbac3bb" ON public.members USING btree (is_featured);


--
-- Name: IDX_535ddf773996ede3697d07ef71; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_535ddf773996ede3697d07ef71" ON public.companies USING btree (uuid);


--
-- Name: IDX_56b91d98f71e3d1b649ed6e9f3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_56b91d98f71e3d1b649ed6e9f3" ON public.refresh_tokens USING btree ("expiresAt");


--
-- Name: IDX_5ce260f54fe07f6361f2ffceac; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_5ce260f54fe07f6361f2ffceac" ON public.activation_tokens USING btree ("expiresAt");


--
-- Name: IDX_5de0609b9e1760faed608577ae; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_5de0609b9e1760faed608577ae" ON public.schedule_breaks USING btree (company_id);


--
-- Name: IDX_68f12ee5d49b0bc9afe417da5a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_68f12ee5d49b0bc9afe417da5a" ON public.exchange_rates USING btree (company_id);


--
-- Name: IDX_7cdd3524a000b1cde5683fc80b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_7cdd3524a000b1cde5683fc80b" ON public.news USING btree (company_id);


--
-- Name: IDX_89a223b4d883067d909eedd355; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_89a223b4d883067d909eedd355" ON public.companies USING btree (domain);


--
-- Name: IDX_8e753d53a2de803b47ed9acec4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_8e753d53a2de803b47ed9acec4" ON public.services USING btree (company_id);


--
-- Name: IDX_951b8f1dfc94ac1d0301a14b7e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_951b8f1dfc94ac1d0301a14b7e" ON public.users USING btree (uuid);


--
-- Name: IDX_aa1cf9361d8b5c8e6d32b14e75; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_aa1cf9361d8b5c8e6d32b14e75" ON public.members USING btree (category);


--
-- Name: IDX_ads_active_carousel; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_ads_active_carousel" ON public.ads USING btree (company_id, is_active, "order", created_at);


--
-- Name: IDX_b97c36be0cf65565fad88588c2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_b97c36be0cf65565fad88588c2" ON public.events USING btree (company_id);


--
-- Name: IDX_ceb8ac1df66da08adcdd8f67ab; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_ceb8ac1df66da08adcdd8f67ab" ON public.ads USING btree (company_id);


--
-- Name: IDX_d422dabc78ff74a8dab6583da0; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_d422dabc78ff74a8dab6583da0" ON public.role_permissions USING btree ("permissionsId");


--
-- Name: IDX_d75eefa29c161d6add2a30a10e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_d75eefa29c161d6add2a30a10e" ON public.members USING btree (status);


--
-- Name: IDX_e0aa1c0f8c54664b4c09bff6c4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_e0aa1c0f8c54664b4c09bff6c4" ON public.members USING btree (company_id);


--
-- Name: IDX_events_agenda; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_events_agenda" ON public.events USING btree (estado, "fechaEvento", "deletedAt");


--
-- Name: IDX_events_slug_en; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_events_slug_en" ON public.events USING btree ("slugEn");


--
-- Name: IDX_events_slug_es; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_events_slug_es" ON public.events USING btree ("slugEs");


--
-- Name: IDX_fa8a83278a138c383122b55708; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_fa8a83278a138c383122b55708" ON public.events USING btree (autor_id);


--
-- Name: IDX_fbcec9c4908de8338081b5bfeb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_fbcec9c4908de8338081b5bfeb" ON public.user_companies USING btree ("companyId");


--
-- Name: IDX_fe3de112a4f7fd559c1d579509; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_fe3de112a4f7fd559c1d579509" ON public.refresh_tokens USING btree (uuid);


--
-- Name: IDX_news_filter; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_news_filter" ON public.news USING btree (estado, categoria, "deletedAt");


--
-- Name: IDX_news_slug_en; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_news_slug_en" ON public.news USING btree ("slugEn");


--
-- Name: IDX_news_slug_es; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_news_slug_es" ON public.news USING btree ("slugEs");


--
-- Name: schedules FK_026d07b928a9675c2b3aa2e37ab; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedules
    ADD CONSTRAINT "FK_026d07b928a9675c2b3aa2e37ab" FOREIGN KEY ("profileId") REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: role_permissions FK_0cb93c5877d37e954e2aa59e52c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT "FK_0cb93c5877d37e954e2aa59e52c" FOREIGN KEY ("rolesId") REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_companies FK_295e2ec0606b47e50687ff46c34; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_companies
    ADD CONSTRAINT "FK_295e2ec0606b47e50687ff46c34" FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens FK_3ddc983c5f7bcf132fd8732c3f4; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT "FK_3ddc983c5f7bcf132fd8732c3f4" FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: schedules FK_4312587691718bbddaf92b4c866; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedules
    ADD CONSTRAINT "FK_4312587691718bbddaf92b4c866" FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: professions FK_4713fa1afaa73ebeeef2d3a8ad0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.professions
    ADD CONSTRAINT "FK_4713fa1afaa73ebeeef2d3a8ad0" FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: user_companies FK_533c70e5f26cbf874cdf2fbfff3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_companies
    ADD CONSTRAINT "FK_533c70e5f26cbf874cdf2fbfff3" FOREIGN KEY ("roleId") REFERENCES public.roles(id);


--
-- Name: schedule_breaks FK_5de0609b9e1760faed608577aec; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_breaks
    ADD CONSTRAINT "FK_5de0609b9e1760faed608577aec" FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: exchange_rates FK_68f12ee5d49b0bc9afe417da5a6; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exchange_rates
    ADD CONSTRAINT "FK_68f12ee5d49b0bc9afe417da5a6" FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: news FK_7cdd3524a000b1cde5683fc80bf; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.news
    ADD CONSTRAINT "FK_7cdd3524a000b1cde5683fc80bf" FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: services FK_8e753d53a2de803b47ed9acec4c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT "FK_8e753d53a2de803b47ed9acec4c" FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: activation_tokens FK_995711dd58f244ad95c829e3e38; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activation_tokens
    ADD CONSTRAINT "FK_995711dd58f244ad95c829e3e38" FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: profiles FK_9e432b7df0d182f8d292902d1a2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT "FK_9e432b7df0d182f8d292902d1a2" FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: news FK_a01e4fe16c466c6b7e1c71a43b6; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.news
    ADD CONSTRAINT "FK_a01e4fe16c466c6b7e1c71a43b6" FOREIGN KEY (autor_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: users FK_a2cecd1a3531c0b041e29ba46e1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "FK_a2cecd1a3531c0b041e29ba46e1" FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: profiles FK_b61819d9d3c02571f756d295abe; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT "FK_b61819d9d3c02571f756d295abe" FOREIGN KEY (profession_id) REFERENCES public.professions(id);


--
-- Name: events FK_b97c36be0cf65565fad88588c28; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT "FK_b97c36be0cf65565fad88588c28" FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: ads FK_ceb8ac1df66da08adcdd8f67ab9; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ads
    ADD CONSTRAINT "FK_ceb8ac1df66da08adcdd8f67ab9" FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: schedule_breaks FK_d25bfa71120389a1a6b62001803; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_breaks
    ADD CONSTRAINT "FK_d25bfa71120389a1a6b62001803" FOREIGN KEY ("scheduleId") REFERENCES public.schedules(id) ON DELETE CASCADE;


--
-- Name: role_permissions FK_d422dabc78ff74a8dab6583da02; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT "FK_d422dabc78ff74a8dab6583da02" FOREIGN KEY ("permissionsId") REFERENCES public.permissions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: members FK_e0aa1c0f8c54664b4c09bff6c41; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT "FK_e0aa1c0f8c54664b4c09bff6c41" FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: events FK_fa8a83278a138c383122b557081; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT "FK_fa8a83278a138c383122b557081" FOREIGN KEY (autor_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: user_companies FK_fbcec9c4908de8338081b5bfeb0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_companies
    ADD CONSTRAINT "FK_fbcec9c4908de8338081b5bfeb0" FOREIGN KEY ("companyId") REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

